
import React, { useEffect } from 'react';
import "../styles/about.css";
import { Link } from "react-router-dom";
import logo from "../img/Shopee.svg.png";
import axios from 'axios';

interface Product {
    image: string;
    name: string;
    price: number;
    quantity: number;
}
function About() {
    const [products, setProduct] = React.useState<Product[]>([])
    const [search, setSearch] = React.useState<string>('')
    const fetchData = async () => {
        try {
            const res = await axios.get('http://localhost:8001/product')
            setProduct(res.data);
        } catch (error) {
            console.log(error)
        }
    }
    useEffect(() => {
        fetchData()
        // fetch('http://localhost:8001/product')
        //     .then((e) => e.json())
        //     .then((x) => {
        //         setProduct(x);
        //     });
    }, []);

   const filter = products.filter((s) => s.name.includes(search) || s.price.toString().includes(search))

    return (
        <div>
            <nav className='nav'>
                <div className='nav-container'>
                    <button className="btn-hamburger">
                        <i className="fas fa-bars"></i>
                    </button>
                    <div className='logo'>
                        <img src={logo} alt="" />
                    </div>
                    <div className='sidebar'>
                        <input type='text' className='sidebar-search' placeholder='Search..'
                            value={search}
                            onChange={(e) => setSearch(e.target.value)} />
                    </div>
                </div>
                <ul className='bars'>
                    <li><Link to="/">Home</Link></li>
                    <li><Link to="about">Shopee</Link></li>
                    <li><Link to="Contact">Contact</Link></li>
                    <li><Link to="Sign in">Sign in</Link></li>
                </ul>
            </nav>

            <div className='product'>

                {
                    filter.map((e: Product) => {
                        return (
                            <div className='product-items'>
                                <img src={e.image} alt="" />
                                <p>ราคาสินค้า : {e.price}$</p>
                                <p>ชื่อสินค้า : {e.name}</p>
                                <p>จำนวนคงเหลือ : {e.quantity}</p>


                            </div>)
                    })
                }
            </div>
        </div>

    );
}

export default About;
